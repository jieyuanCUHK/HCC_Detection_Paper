####################################Code for computing Machine Learning Metrics########################
library(MLmetrics)
#############################################Read Input#########################################################
snv_results_ori=read.table("./0_Input",header=TRUE,sep="\t")
rownames(snv_results_ori)=snv_results_ori[,1]
snv_results_ori[snv_results_ori[,4]=="Yes",4]=1
snv_results_ori[snv_results_ori[,4]=="No",4]=0

#Randomly get 20%
snv_results=snv_results_ori[sample(nrow(snv_results_ori), round(0.2*nrow(snv_results_ori)),0),]

###########################################Compute the metrics##############################################################
#计算结果：
#(1) specificity
c(Specificity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"),Specificity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"),Specificity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"),Specificity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"),Specificity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"),Specificity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))

#(2) Sensitivity
c(Sensitivity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"),Sensitivity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"),Sensitivity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"),Sensitivity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"),Sensitivity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"),Sensitivity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))

#(3) Precision
c(Precision(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"),Precision(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"),Precision(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"),Precision(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"),Precision(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"),Precision(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))

#(4) TP, FP, TN, FN
#TP: ConfusionMatrix[2,2]
#FP: ConfusionMatrix[1,2]
#TN: ConfusionMatrix[1,1]
#FN: ConfusionMatrix[2,1]

#(5) NPV=TN/(TN+FN)
c(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[2,1]))

#(6) Accuracy
c(Accuracy(y_pred=snv_results[,3],y_true=snv_results[,4]),Accuracy(y_pred=snv_results[,6],y_true=snv_results[,4]),Accuracy(y_pred=snv_results[,8],y_true=snv_results[,4]),Accuracy(y_pred=snv_results[,10],y_true=snv_results[,4]),Accuracy(y_pred=snv_results[,12],y_true=snv_results[,4]),Accuracy(y_pred=snv_results[,14],y_true=snv_results[,4]))

#(7) F1 Score:
c(F1_Score(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"),F1_Score(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"),F1_Score(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"),F1_Score(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"),F1_Score(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"),F1_Score(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))

#(8) False Omission Rate:
c(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[2,1]/(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[2,1]/(ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[2,1]/(ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[2,1]/(ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[2,1]/(ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[2,1]),ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[2,1]/(ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[2,1]))

#(9) PLR=sensitivity/(1-specificity)
c(Sensitivity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1")/(1-Specificity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1")),Sensitivity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1")/(1-Specificity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1")),Sensitivity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1")/(1-Specificity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1")),Sensitivity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1")/(1-Specificity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1")),Sensitivity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1")/(1-Specificity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1")),Sensitivity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1")/(1-Specificity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1")))
	

#(10) NLR=(1-Sensitivity)/Specificity
c((1-Sensitivity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"))/Specificity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"),(1-Sensitivity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"))/Specificity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"),(1-Sensitivity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"))/Specificity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"),(1-Sensitivity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"))/Specificity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"),(1-Sensitivity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"))/Specificity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"),(1-Sensitivity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))/Specificity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))

#(11) Matthews Correlation Coefficient
#Each ML method has one command;
sqrt(Sensitivity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1")*Specificity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1")*Precision(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1")*(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[2,1])))-sqrt((1-Sensitivity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"))*(1-Specificity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1"))*(1-ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[2,1]))*(1-Precision(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1")))

sqrt(Sensitivity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1")*Specificity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1")*Precision(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1")*(ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[2,1])))-sqrt((1-Sensitivity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"))*(1-Specificity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1"))*(1-ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[2,1]))*(1-Precision(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1")))

sqrt(Sensitivity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1")*Specificity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1")*Precision(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1")*(ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[2,1])))-sqrt((1-Sensitivity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"))*(1-Specificity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1"))*(1-ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[2,1]))*(1-Precision(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1")))

sqrt(Sensitivity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1")*Specificity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1")*Precision(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1")*(ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[2,1])))-sqrt((1-Sensitivity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"))*(1-Specificity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1"))*(1-ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[2,1]))*(1-Precision(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1")))

sqrt(Sensitivity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1")*Specificity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1")*Precision(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1")*(ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[2,1])))-sqrt((1-Sensitivity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"))*(1-Specificity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1"))*(1-ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[2,1]))*(1-Precision(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1")))

sqrt(Sensitivity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1")*Specificity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1")*Precision(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1")*(ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[2,1])))-sqrt((1-Sensitivity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))*(1-Specificity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1"))*(1-ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,1]/(ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,1]+ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[2,1]))*(1-Precision(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1")))


#(12) Fowlkes-Mallows Index:
c(sqrt(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[2,2]/(ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[2,2]+ConfusionMatrix(y_pred=snv_results[,3],y_true=snv_results[,4])[1,2])*Sensitivity(y_pred=snv_results[,3],y_true=snv_results[,4],positive="1")),sqrt(ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[2,2]/(ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[2,2]+ConfusionMatrix(y_pred=snv_results[,6],y_true=snv_results[,4])[1,2])*Sensitivity(y_pred=snv_results[,6],y_true=snv_results[,4],positive="1")),sqrt(ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[2,2]/(ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[2,2]+ConfusionMatrix(y_pred=snv_results[,8],y_true=snv_results[,4])[1,2])*Sensitivity(y_pred=snv_results[,8],y_true=snv_results[,4],positive="1")),sqrt(ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[2,2]/(ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[2,2]+ConfusionMatrix(y_pred=snv_results[,10],y_true=snv_results[,4])[1,2])*Sensitivity(y_pred=snv_results[,10],y_true=snv_results[,4],positive="1")),sqrt(ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[2,2]/(ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[2,2]+ConfusionMatrix(y_pred=snv_results[,12],y_true=snv_results[,4])[1,2])*Sensitivity(y_pred=snv_results[,12],y_true=snv_results[,4],positive="1")),sqrt(ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[2,2]/(ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[2,2]+ConfusionMatrix(y_pred=snv_results[,14],y_true=snv_results[,4])[1,2])*Sensitivity(y_pred=snv_results[,14],y_true=snv_results[,4],positive="1")))

#(13) AUC:
c(AUC(y_pred=snv_results[,3], y_true=snv_results[,4]),AUC(y_pred=snv_results[,6], y_true=snv_results[,4]),AUC(y_pred=snv_results[,8], y_true=snv_results[,4]),AUC(y_pred=snv_results[,10], y_true=snv_results[,4]),AUC(y_pred=snv_results[,12], y_true=snv_results[,4]),AUC(y_pred=snv_results[,14], y_true=snv_results[,4]))

#(14) AUC: not thresholded:
c(AUC(y_pred=snv_results[,2], y_true=snv_results[,4]),AUC(y_pred=snv_results[,5], y_true=snv_results[,4]),AUC(y_pred=snv_results[,7], y_true=snv_results[,4]),AUC(y_pred=snv_results[,9], y_true=snv_results[,4]),AUC(y_pred=snv_results[,11], y_true=snv_results[,4]),AUC(y_pred=snv_results[,13], y_true=snv_results[,4]))

#############################################ROC Cruve Plot#############################
snv_results=read.table("./0_Input",sep="\t")
labels <- snv_results[,4]

library(pROC)

lr <- roc(labels,snv_results$LR_insertsize)
randomforest=roc(labels,snv_results$RandomForestClassifier_insertsize)
sgd <- roc(labels,snv_results$SGDClassifier_insertsize)
gaussian=roc(labels,snv_results$GaussianNB_insertsize)
bernoulli=roc(labels,snv_results$BernoulliNB_insertsize)

ggroc(list(SGD=sgd,RF=randomforest,Gaussian=gaussian,Ber=bernoulli,LR=lr),linetype = 1, size = 1,alpha=0.8,legacy.axes = T)+theme_bw()+scale_color_manual(values=c("#9DB4C0", "#563672","#4C5C68", "#C2DFE3","#253237"))+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),axis.text=element_text(size=13,colour = "black"),axis.title=element_text(size=14),axis.ticks = element_line(colour = "black", size = 1.5),panel.background=element_rect(colour="black",size=1.5))
auc(sgd)
auc(randomforest)
auc(gaussian)
auc(bernoulli)
auc(lr)