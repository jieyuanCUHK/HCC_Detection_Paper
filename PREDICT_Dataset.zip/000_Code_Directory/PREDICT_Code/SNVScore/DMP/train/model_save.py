#!usr/bin/env python3.7
#coding:utf8                       

"""
model_save将调好超参数
并且训练好的模型保存起来，
便于加载使用
"""

__version__="1.0.0"

# from sklearn.externals import joblib
import joblib
import os

class ModelSaveConfig:
    """
    模型保存的路径和名称
    :param model_save_path : str
        模型保存的地址
    :param save_path_name: str
        模型保存的名称
    """
    def __init__(self, model_save_path, save_path_name):
        if not os.path.isdir(model_save_path):
            os.makedirs(model_save_path)
        self.model_save_path = model_save_path
        self.save_path_name = save_path_name
        
class ModelSaveLoadHandle():
    """
    模型的保存和加载处理
    :param msc : str
        模型保存的地址和名称
    :param model: str
        要保存的模型
    """
    def __init__(self, msc):
        self.msc = msc
        
    def save(self, model):
        """
        模型保存
        """
        joblib.dump(model, self.msc.model_save_path+self.msc.save_path_name)
        
    def load(self):
        """
        模型加载
        """
        model = joblib.load(self.msc.model_save_path+self.msc.save_path_name)
        return model
        
if __name__ == "__main__":
    model_save_path = "/mnt/X500/farmers/limin/Models/"
    save_path_name = best_model_name+".m"
    msc = ms.ModelSaveConfig(model_save_path, save_path_name)
    mslh = ms.ModelSaveLoadHandle(msc)
    mslh.save(best_model)
    model = mslh.load()
    model.predict_proba(X)
