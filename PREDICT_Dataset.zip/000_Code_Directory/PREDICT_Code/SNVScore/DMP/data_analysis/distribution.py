#!/usr/bin/python
#coding:utf8

"""
    多个数值特征分别的数值分布图.
"""

import matplotlib as mlp
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()
import chart_studio.plotly as py
import plotly.graph_objs as go
from plotly import tools
from plotly.offline import init_notebook_mode, iplot, plot
init_notebook_mode(connected=True)

from math import ceil


def single_feature_histogram(filename, x, x_name="reads count(M)",histnorm="", xbins=dict(size=5)):
    """*******************************
    参数：
    histnorm可以取值为'percent', 'probability', 'density', 'probability density'，用法参考go.Histogram;
    *******************************"""
    data = [go.Histogram(x=x, histnorm=histnorm, xbins=xbins, autobinx=False)]
    layout = go.Layout(yaxis=dict(title=histnorm+"("+str(len(x))+")"), xaxis=dict(title=x_name))
    fig = dict(data=data, layout=layout)
    iplot(fig)
    plot(fig, filename=filename)
    
def sns_single_feature_histogram(x):
    """*******************************
    参数：
    *******************************"""
    mlp.rc("figure", figsize=(12, 6))
    sns.distplot(x, kde_kws={"color": "seagreen", "lw":2, "label" : "KDE" }, bins=20, hist_kws={"histtype": "step", "color": "slategray" })
    plt.ylabel(u'probability density')
    plt.show()
    

def multi_feature_histogram(filename=None, image_filename=None, histnorm="", x_name="reads count(M)", xbins=dict(size=5), **x_dic):
    """
    多个数值特征分别的数值分布图.
    *******************************
    参数：
    histnorm可以取值为'percent', 'probability', 'density', 'probability density'，用法参考go.Histogram;
    x_dic是特征名和特征值字典;
    *******************************
    -------------------------------
    用例：
    x_dict = {
    "AF": Mutation_DF["AF"],
    "MutClass": Mutation_DF["MutClass"],
    }
    multi_feature_histogram(**x_dict)
    -------------------------------

    """
    # 数据
    x_names = [x_name for x_name, x in x_dic.items()]
    xs = [x for x_name, x in x_dic.items()]
    # 行列
    nr_cols = 3
    nr_rows = ceil(len(x_dic) / nr_cols)#向上取整
    # 初始化图
    fig = tools.make_subplots(rows=nr_rows, cols=nr_cols, print_grid=False,
                              subplot_titles=x_names)

    # 图加入数据
    for row in range(1, nr_rows + 1):
        for col in range(1, nr_cols + 1):
            i = (row - 1) * nr_cols + col - 1
            if i < len(xs):
                trace = go.Histogram(x=xs[i], histnorm=histnorm, xbins=xbins,)
                fig.append_trace(trace, row, col)

    # 图排版
    fig['layout'].update(height=100 + 200 * nr_rows, width=900, showlegend=False,
                         title="{}:{}".format(x_name,histnorm),#yaxis = dict(title=histnorm+"("+str(len(xs[0]))+")"),
                         **{"yaxis"+str(i+1):dict(title=histnorm+"("+str(len(xs[i]))+")") for i in range(0, len(xs))},
                         **{"xaxis"+str(i+1):dict(title=x_name) for i in range(0, len(xs))}
                        )
    iplot(fig)
    if filename is not None:
        plot(fig, filename=filename, image="svg", image_filename=image_filename)