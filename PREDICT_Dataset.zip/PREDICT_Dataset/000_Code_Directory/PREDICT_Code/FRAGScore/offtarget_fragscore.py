# !/usr/bin/env python3.7
# coding:utf8

import os
import pandas as pd

from pathlib import Path
appdir = Path(__file__).resolve().parent
import sys
sys.path.append(r'{}/bin'.format(appdir))
import offtarget_downSample as od
import fragmentation as frg
import fragmentation_arm_insertsize as frg_arm_insertsize
import load_insertsize as li
import argparse

def checkPath(*paths):
    """
    check path exists or not
    """
    for path in paths:
        if not os.path.exists(path):
            os.makedirs(path, mode=0o777)
        else:
            print("{} path already exists".format(path))


def opt():
    args = argparse.ArgumentParser()
    args.add_argument('-b', '--bam', dest='single sample offtarget bam', required=True,
                      help="one sample offtarget bam, [str]")
    args.add_argument('-o', '--outdir', dest='output directory', required=False,
                      help="the output directory, [str]")
    args.add_argument('-c', '--chip', dest='the chip bed', required=False,
                      help="chip bed used by the sample")
    return args.parse_args()


# generate insertsize feature
def generate_feature(bam_path, out_path, chipFile, flk=""):
    checkPath("{}/offtargetRegion".format(out_path))
    od.prepare_savepath_bamT(bam_path, out_path, chipFile, flk=flk)
    frg.fragmentation_zscore(out_path, flk=flk)
    frg_arm_insertsize.fragmentation_arm_insersize(out_path, flk=flk)


def main():
    args = opt()
    bam_path = args.bam
    out_path = args.outdir
    chip_file = args.chip
    
    down_sample_reads = "3M"
    flk = ""
    region = (90,600)
    regions = [(90,92), (94,98), (131,136), (139,147), (151,161), (166,166), (168,187), (189,189), (191,195), (200,249), (251,259), (273,275), (278,311), (323,323), (325,325), (327,329), (331,374), (376,377), (379,379), (393,394), (396,396), (398,420), (422,426), (428,431), (433,433), (435,435), (449,450), (452,462), (464,527), (529,533), (540,540), (543,543), (548,548), (565,565), (584,584)]

    # generate fragment feature
    generate_feature(bam_path, out_path, chip_file, flk=flk)

    insersize = "{}/offtargetRegion/insertsize{}/".format(out_path, down_sample_reads)
    frg = "{}/offtargetRegion/frg_zscore{}/".format(out_path, flk)

    insertsize_df = li.get_insertsize(insersize, region=region)
    pq_zscore_df = li.get_pq_zscore(frg)
    insertsize_df = insertsize_df.join(pq_zscore_df, how="inner")
    for start, end in regions:
        insertsize_df["{}-{}".format(start,end)] = insertsize_df[[str(i) for i in range(start,end+1)]].T.sum()
    insertsize_df.to_csv("{}/insertsize_result.tsv".format(out_path),sep='\t')

if __name__ == "__main__":
    main()