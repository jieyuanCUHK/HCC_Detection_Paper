from pathlib import Path
appdir = Path(__file__).resolve().parent
import sys
sys.path.append(r'{}/'.format(appdir))
import pandas as pd
from DMP.train.abstract_pipeline_factory import PipelineConfig, grid_search_cv
from DMP.train.classification_pipeline_factory import ClassificationFactory
from DMP.train import cross_validation_evaluation as cve
from DMP.train import model_save as ms


def main():
    # 1.read snv feature
    cirrhosis_liver_snv_feature_df = pd.read_excel("SNV_features_retrospective.xlsx")
    # judge snv type: tumor informed or not
    cirrhosis_liver_snv_feature_df["y"] = cirrhosis_liver_snv_feature_df[["has_matched_tumor", "Tumor_informed"]].apply(lambda x: 0 if x[0] == 0 or x[0] == 1 and x[1] == 0 else (1 if x[0] == 1 and x[1] == 1 else 0), axis=1)

    # 2.1 train dataset
    # liver cancer sample snv: which is called in matched tumor tissue sample
    # cirrhosis sample snv
    train_sample_df = cirrhosis_liver_snv_feature_df[(cirrhosis_liver_snv_feature_df["has_matched_tumor"] == 1) & (cirrhosis_liver_snv_feature_df["Tumor_informed"] == 1)]
    cirrhosis_liver_snv_feature_train_df = cirrhosis_liver_snv_feature_df[(cirrhosis_liver_snv_feature_df["sampleID"].isin(train_sample_df["sampleID"])) | (cirrhosis_liver_snv_feature_df["has_matched_tumor"] == 0)]

    # 2.2 test dataset
    # liver cancer snv: which is not called in matched tumor tissue sample
    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_df[(~cirrhosis_liver_snv_feature_df["sampleID"].isin(train_sample_df["sampleID"])) & (cirrhosis_liver_snv_feature_df["has_matched_tumor"] == 1)]

    # 2.3 train process
    # 2.3.1 grid search
    trans_args = {
        "numerical_features": [
            'mean_bc_family_size',
            'mean_norm_varpos',
            'mean_var_phred_score',
            'fraction_MapQmin30',
            'sum_log10_frag_size_enrich_score',
            'size_selected_adjustment',
            'mean_num_non_ref_bases',
            'variant_norm_bc_fam_size',
            'normalized_depth',
            'duplex_reads',
            'watsoncrickfisher.p',
            "ProbMin2ReadGerm_signed",
            "power_binary"
        ],
        "categorical_features": [
            'base_change_transition',
        ],
        "other_features": []
    }
    pc = PipelineConfig(0, 0, **trans_args)
    pcf = ClassificationFactory(pc)
    multi_algo_pipelines = pcf.create_multi_algo_pipelines().get_pipelines()
    pipelines = [pipeline.get('pipeline') for pipe_name, pipeline in multi_algo_pipelines.items()]
    for i in trans_args["numerical_features"]:
        cirrhosis_liver_snv_feature_train_df[i] = cirrhosis_liver_snv_feature_train_df[i].astype(float)
        cirrhosis_liver_snv_feature_test_df[i] = cirrhosis_liver_snv_feature_test_df[i].astype(float)
    multi_algo_pipelines_parameter = pcf.add_multi_algo_pipelines_parameter().get_pipelines()
    y = cirrhosis_liver_snv_feature_train_df[["y"]]
    models_raw = {}
    i = 0
    for pipe_name, pipeline in multi_algo_pipelines_parameter.items():
        if pipe_name == "LogisticRegression" or pipe_name == "SGDClassifier" or pipe_name == "RandomForestClassifier" or pipe_name == "GaussianNB" or pipe_name == "BernoulliNB":
            pipe_algo = pipeline.get("pipeline")
            pipe_para = pipeline.get("pipeline_parameter")
            model, score = grid_search_cv(cirrhosis_liver_snv_feature_train_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y, pipe_algo, pipe_para, scoring='roc_auc')
            models_raw[pipe_name] = model

    # 2.3.2 validate model and hyperparameter
    # LogisticRegression
    y = cirrhosis_liver_snv_feature_train_df["y"]
    pre = cve.cv_predict(models_raw['LogisticRegression'], cirrhosis_liver_snv_feature_train_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.02)

    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.reset_index()
    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.drop("index", axis=1)
    test_result = models_raw["LogisticRegression"].predict_proba(cirrhosis_liver_snv_feature_test_df)
    cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"] = pd.DataFrame(test_result)[1]
    cirrhosis_liver_snv_feature_test_df["y"] = cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_train_df, cirrhosis_liver_snv_feature_test_df])

    y = cirrhosis_liver_snv_feature_df[["y"]]
    models = {}
    i = 0
    for pipe_name, pipeline in multi_algo_pipelines_parameter.items():
        if pipe_name == "LogisticRegression":
            pipe_algo = pipeline.get("pipeline")
            pipe_para = pipeline.get("pipeline_parameter")
            model, score = grid_search_cv(cirrhosis_liver_snv_feature_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y, pipe_algo, pipe_para, scoring='roc_auc')
            models[pipe_name] = model
            print(pipe_name+":"+str(score))
    y = cirrhosis_liver_snv_feature_df["y"]
    pre = cve.cv_predict(models['LogisticRegression'], cirrhosis_liver_snv_feature_df, y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.1)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_df, pre], axis=1)
    cirrhosis_liver_snv_feature_df["LogisticRegression"] = cirrhosis_liver_snv_feature_df[1]
    cirrhosis_liver_snv_feature_df["LogisticRegression_predict"] = cirrhosis_liver_snv_feature_df["LogisticRegression"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df_LogisticRegression_predict = cirrhosis_liver_snv_feature_df.drop("y", axis=1)
    cirrhosis_liver_snv_feature_df_LogisticRegression_predict.to_csv("cirrhosis_liver_snv_feature_df_LogisticRegression_predict.txt", sep="\t")

    # SGDClassifier
    y = cirrhosis_liver_snv_feature_train_df["y"]
    pre = cve.cv_predict(models_raw['SGDClassifier'], cirrhosis_liver_snv_feature_train_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.02)

    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.reset_index()
    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.drop("index", axis=1)
    test_result = models_raw["SGDClassifier"].predict_proba(cirrhosis_liver_snv_feature_test_df)
    cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"] = pd.DataFrame(test_result)[1]
    cirrhosis_liver_snv_feature_test_df["y"] = cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_train_df, cirrhosis_liver_snv_feature_test_df])

    y = cirrhosis_liver_snv_feature_df[["y"]]
    models = {}
    i = 0
    for pipe_name, pipeline in multi_algo_pipelines_parameter.items():
        if pipe_name == "SGDClassifier":
            pipe_algo = pipeline.get("pipeline")
            pipe_para = pipeline.get("pipeline_parameter")
            model, score = grid_search_cv(cirrhosis_liver_snv_feature_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y, pipe_algo, pipe_para, scoring='roc_auc')
            models[pipe_name] = model
            print(pipe_name+":"+str(score))

    y = cirrhosis_liver_snv_feature_df["y"]
    pre = cve.cv_predict(models['SGDClassifier'], cirrhosis_liver_snv_feature_df, y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.1)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_df, pre], axis=1)
    cirrhosis_liver_snv_feature_df["SGDClassifier"] = cirrhosis_liver_snv_feature_df[1]
    cirrhosis_liver_snv_feature_df["SGDClassifier_predict"] = cirrhosis_liver_snv_feature_df["SGDClassifier"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df_SGDClassifier_predict = cirrhosis_liver_snv_feature_df.drop("y", axis=1)
    cirrhosis_liver_snv_feature_df_SGDClassifier_predict.to_csv("cirrhosis_liver_snv_feature_df_SGDClassifier_predict.txt", sep="\t")
    
    # RandomForestClassifier
    y = cirrhosis_liver_snv_feature_train_df["y"]
    pre = cve.cv_predict(models_raw['RandomForestClassifier'], cirrhosis_liver_snv_feature_train_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.02)

    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.reset_index()
    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.drop("index", axis=1)
    test_result = models_raw["RandomForestClassifier"].predict_proba(cirrhosis_liver_snv_feature_test_df)
    cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"] = pd.DataFrame(test_result)[1]
    cirrhosis_liver_snv_feature_test_df["y"] = cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_train_df, cirrhosis_liver_snv_feature_test_df])

    y = cirrhosis_liver_snv_feature_df[["y"]]
    models = {}
    i = 0
    for pipe_name, pipeline in multi_algo_pipelines_parameter.items():
        if pipe_name == "RandomForestClassifier":
            pipe_algo = pipeline.get("pipeline")
            pipe_para = pipeline.get("pipeline_parameter")
            model, score = grid_search_cv(cirrhosis_liver_snv_feature_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y, pipe_algo, pipe_para, scoring='roc_auc')
            models[pipe_name]=model
            print(pipe_name+":"+str(score))

    y = cirrhosis_liver_snv_feature_df["y"]
    pre = cve.cv_predict(models['RandomForestClassifier'], cirrhosis_liver_snv_feature_df, y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.1)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_df, pre], axis=1)
    cirrhosis_liver_snv_feature_df["RandomForestClassifier"] = cirrhosis_liver_snv_feature_df[1]
    cirrhosis_liver_snv_feature_df["RandomForestClassifier_predict"] = cirrhosis_liver_snv_feature_df["RandomForestClassifier"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df_RandomForestClassifier_predict = cirrhosis_liver_snv_feature_df.drop("y", axis=1)
    cirrhosis_liver_snv_feature_df_RandomForestClassifier_predict.to_csv("cirrhosis_liver_snv_feature_df_RandomForestClassifier_predict.txt", sep="\t")

    # GaussianNB
    y = cirrhosis_liver_snv_feature_train_df["y"]
    pre = cve.cv_predict(models_raw['GaussianNB'], cirrhosis_liver_snv_feature_train_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.02)

    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.reset_index()
    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.drop("index", axis=1)
    test_result = models_raw["GaussianNB"].predict_proba(cirrhosis_liver_snv_feature_test_df)
    cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"] = pd.DataFrame(test_result)[1]
    cirrhosis_liver_snv_feature_test_df["y"] = cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_train_df, cirrhosis_liver_snv_feature_test_df])

    y = cirrhosis_liver_snv_feature_df[["y"]]
    models = {}
    i = 0
    for pipe_name, pipeline in multi_algo_pipelines_parameter.items():
        if pipe_name == "GaussianNB":
            pipe_algo = pipeline.get("pipeline")
            pipe_para = pipeline.get("pipeline_parameter")
            model, score = grid_search_cv(cirrhosis_liver_snv_feature_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y, pipe_algo, pipe_para, scoring='roc_auc')
            models[pipe_name] = model
            print(pipe_name+":"+str(score))

    y = cirrhosis_liver_snv_feature_df["y"]
    pre = cve.cv_predict(models['GaussianNB'], cirrhosis_liver_snv_feature_df, y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.1)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_df, pre], axis=1)
    cirrhosis_liver_snv_feature_df["GaussianNB"] = cirrhosis_liver_snv_feature_df[1]
    cirrhosis_liver_snv_feature_df["GaussianNB_predict"] = cirrhosis_liver_snv_feature_df["GaussianNB"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df_GaussianNB_predict = cirrhosis_liver_snv_feature_df.drop("y", axis=1)
    cirrhosis_liver_snv_feature_df_GaussianNB_predict.to_csv("cirrhosis_liver_snv_feature_df_GaussianNB_predict.txt",sep="\t")

    # BernoulliNB
    y = cirrhosis_liver_snv_feature_train_df["y"]
    pre = cve.cv_predict(models_raw['BernoulliNB'], cirrhosis_liver_snv_feature_train_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.02)

    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.reset_index()
    cirrhosis_liver_snv_feature_test_df = cirrhosis_liver_snv_feature_test_df.drop("index", axis=1)
    test_result = models_raw["BernoulliNB"].predict_proba(cirrhosis_liver_snv_feature_test_df)
    cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"] = pd.DataFrame(test_result)[1]
    cirrhosis_liver_snv_feature_test_df["y"] = cirrhosis_liver_snv_feature_test_df["label_in_final_snv_model_p"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_train_df, cirrhosis_liver_snv_feature_test_df])

    y = cirrhosis_liver_snv_feature_df[["y"]]
    models = {}
    i = 0
    for pipe_name, pipeline in multi_algo_pipelines_parameter.items():
        if pipe_name == "BernoulliNB":
            pipe_algo = pipeline.get("pipeline")
            pipe_para = pipeline.get("pipeline_parameter")
            model, score = grid_search_cv(cirrhosis_liver_snv_feature_df[trans_args["numerical_features"]+trans_args["categorical_features"]], y, pipe_algo, pipe_para, scoring='roc_auc')
            models[pipe_name] = model
            print(pipe_name+":"+str(score))

    y = cirrhosis_liver_snv_feature_df["y"]
    pre = cve.cv_predict(models['BernoulliNB'], cirrhosis_liver_snv_feature_df, y)
    threshold = cve.drawROC_t_Specificity(pre[1], y, 0.1)
    cirrhosis_liver_snv_feature_df = pd.concat([cirrhosis_liver_snv_feature_df, pre], axis=1)
    cirrhosis_liver_snv_feature_df["BernoulliNB"] = cirrhosis_liver_snv_feature_df[1]
    cirrhosis_liver_snv_feature_df["BernoulliNB_predict"] = cirrhosis_liver_snv_feature_df["BernoulliNB"].apply(lambda x: 1 if x >= threshold else 0)
    cirrhosis_liver_snv_feature_df_BernoulliNB_predict = cirrhosis_liver_snv_feature_df.drop("y", axis=1)
    cirrhosis_liver_snv_feature_df_BernoulliNB_predict.to_csv("cirrhosis_liver_snv_feature_df_BernoulliNB_predict.txt", sep="\t")


if __name__ == "__main__":
    main()
