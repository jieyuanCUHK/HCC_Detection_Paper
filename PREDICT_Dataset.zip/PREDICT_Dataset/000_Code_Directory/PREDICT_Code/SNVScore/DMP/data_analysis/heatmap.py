#!/usr/bin/python
#coding:utf8

"""
热图
"""
import matplotlib.pyplot as plt
import seaborn as sns
#%matplotlib inline
sns.set()
import chart_studio.plotly as py
import plotly.graph_objs as go
from plotly import tools
from plotly.offline import init_notebook_mode, iplot
init_notebook_mode(connected=True)

def corr_heatmap(dataFrame):
    """
    dataFrame数值型列的相关关系.
    """
    corr = dataFrame.corr()
    fig = go.Figure(data=go.Heatmap(
                    x=corr.index,
                    y=corr.columns,
                    z=corr,
                    ))
    iplot(fig)