#!/usr/bin/python
#coding:utf8

u"""
对DataFrame数据进行初步探索
"""
def first_explore(DF):
    u"""
    对DataFrame数据进行初步探索
    :param DF: 
    :return: 
    """
    print(u"数据量:",DF.shape)
#     print("-"*50)
#     print(u"数据前5行:")
#     print(DF.head())
    print("-"*50)
    print(u"数据各列的类型:")
    DF.info()
    print("-"*50)
    print(u"数据各列的空值信息:")
    print(DF.isnull().sum(axis=0))
    print("-"*50)
    print(u"数据中数值列的数学描述:")
    print(DF.describe())