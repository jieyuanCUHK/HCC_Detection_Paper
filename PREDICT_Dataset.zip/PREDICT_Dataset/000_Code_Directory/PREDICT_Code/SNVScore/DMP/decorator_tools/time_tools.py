__author__="Min Li"
# !usr/bin/env python3.7
# coding:utf8

u"""
timecost
"""
from datetime import datetime

def timecost(func):
    def wrapped(*args, **kw):
        start = datetime.now()
        result = func(*args, **kw)
        print("cost time = ", datetime.now()-start)
        print(result)
    return wrapped