#!/usr/bin/python
#coding:utf8
# 在jupyter上一步一步使用
if __name__ == "__main__":
    # 配置文件路径
    # 配置输入输出
    # 配置问题类型(分类、回归、聚类、排序)

    # 解析配置文件

    # 可视化分析

    # 特征工程、算法选择(超参数调优)（pipeline）
    print()
