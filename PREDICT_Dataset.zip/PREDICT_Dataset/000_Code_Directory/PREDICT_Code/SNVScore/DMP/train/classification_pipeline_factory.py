# !usr/bin/env python3.7
# coding:utf8

"""
pipeline便于数据挖掘流程的管理
使用sklearn的Pipeline工具自定义一个pipeline装饰器
装饰多个算法，便于多算法比较
"""

__version__ = "1.0.0"


# 算法
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.naive_bayes import GaussianNB, BernoulliNB
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier
# import xgboost as xgb
# from xgboost import XGBClassifier
from mlxtend.classifier import StackingClassifier

from .abstract_pipeline_factory import AbstractPipeline, AbstractPipelineParameter, AbstractFactory


class ClassificationPipeline(AbstractPipeline):
    def multi_algo_pipelines(self):
        @self.pw
        def gNB():
            return GaussianNB()

        @self.pw
        def bNB():
            return BernoulliNB()

        @self.pw
        def lr():
            return LogisticRegression()
        
        @self.pw
        def sgd():
            return SGDClassifier(loss="log", penalty="elasticnet", learning_rate="adaptive", eta0=0.01)

        @self.pw
        def svc():
            return SVC(gamma='auto', probability=True)

        @self.pw
        def mlpC():
            return MLPClassifier()

        @self.pw
        def dtC():
            return DecisionTreeClassifier()

        @self.pw
        def rfC():
            return RandomForestClassifier()

        @self.pw
        def adabC():
            return AdaBoostClassifier()

        @self.pw
        def gbC():
            return GradientBoostingClassifier()

        # @self.pw
        # def xgbC():
        #     return XGBClassifier()
        
        @self.pw
        def stackingC():
            lr = LogisticRegression()
            svc = SVC(gamma='auto', probability=True)
            mlp = MLPClassifier()
            stack = StackingClassifier(classifiers = [svc, mlp], use_probas=True,
                           meta_classifier = lr)
            return stack
        

        self.gNB = gNB
        self.bNB = bNB
        self.lr = lr
        self.sgd = sgd
        self.svc = svc
        self.mlpC = mlpC
        self.dtC = dtC
        self.rfC = rfC
        self.adabC = adabC
        self.gbC = gbC
        # self.xgbC = xgbC
        self.stackingC = stackingC
        return self


class ClassificationPipelineParameter(AbstractPipelineParameter):
    def multi_algo_pipelines_parameter(self):
        @self.ppw
        def gNB():
            return {
            }

        @self.ppw
        def bNB():
            return {
            }

        @self.ppw
        def lr():
            return {
                "lr__penalty": ["l1", "l2"],
                "lr__class_weight": ["balanced"],
                "lr__C": [1.0],
                "lr__fit_intercept": [True, False]
            }
        
        @self.ppw
        def sgd():
            return {
                "sgd__penalty": ["elasticnet"],
                "sgd__class_weight": ["balanced"],
            }

        @self.ppw
        def svc():
            return {
            }

        @self.ppw
        def mlpC():
            return {
            }

        @self.ppw
        def dtC():
            return {
            }

        @self.ppw
        def rfC():
            return {
            }

        @self.ppw
        def adabC():
            return {
            }

        @self.ppw
        def gbC():
            return {
            }

        # @self.ppw
        # def xgbC():
        #     return {
        #     }
        
        @self.ppw
        def stackingC():
            return {
            }

        self.gNB = gNB
        self.bNB = bNB
        self.lr = lr
        self.sgd = sgd
        self.svc = svc
        self.mlpC = mlpC
        self.dtC = dtC
        self.rfC = rfC
        self.adabC = adabC
        self.gbC = gbC
        # self.xgbC = xgbC
        self.stackingC = stackingC
        return self


class ClassificationFactory(AbstractFactory):
    def create_multi_algo_pipelines(self):
        cp = ClassificationPipeline(self.pc).multi_algo_pipelines()
        pipe_gNB = cp.gNB()
        pipe_bNB = cp.bNB()
        pipe_lr = cp.lr()
        pipe_sgd = cp.sgd()
        pipe_svc = cp.svc()
        pipe_mlpC = cp.mlpC()
        pipe_dtC = cp.dtC()
        pipe_rfC = cp.rfC()
        pipe_adabC = cp.adabC()
        pipe_gbC = cp.gbC()
        # pipe_xgbC = cp.xgbC()
        pipe_stackingC = cp.stackingC()
        pipelines = {
            "GaussianNB": {"pipeline": pipe_gNB, },
            "BernoulliNB": {"pipeline": pipe_bNB, },
            "LogisticRegression": {"pipeline": pipe_lr, },
            "SGDClassifier": {"pipeline": pipe_sgd, },
            "SVC": {"pipeline": pipe_svc, },
            "MLPClassifier": {"pipeline": pipe_mlpC, },
            "DecisionTreeClassifier": {"pipeline": pipe_dtC, },
            "RandomForestClassifier": {"pipeline": pipe_rfC, },
            "AdaBoostClassifier": {"pipeline": pipe_adabC, },
            "GradientBoostingClassifier": {"pipeline": pipe_gbC, },
            # "XGBClassifier": {"pipeline": pipe_xgbC},
            "StackingClassifier" : {"pipeline": pipe_stackingC}
        }
        self.pipelines = pipelines
        return self

    def add_multi_algo_pipelines_parameter(self):
        cpp = ClassificationPipelineParameter(self.pc).multi_algo_pipelines_parameter()
        pipe_para_gNB = cpp.gNB()
        pipe_para_bNB = cpp.bNB()
        pipe_para_lr = cpp.lr()
        pipe_para_sgd = cpp.sgd()
        pipe_para_svc = cpp.svc()
        pipe_para_mlpC = cpp.mlpC()
        pipe_para_dtC = cpp.dtC()
        pipe_para_rfC = cpp.rfC()
        pipe_para_adabC = cpp.adabC()
        pipe_para_gbC = cpp.gbC()
        # pipe_para_xgbC = cpp.xgbC()
        pipe_para_stackingC = cpp.stackingC()
        self.pipelines["GaussianNB"]["pipeline_parameter"] = pipe_para_gNB
        self.pipelines["BernoulliNB"]["pipeline_parameter"] = pipe_para_bNB
        self.pipelines["LogisticRegression"]["pipeline_parameter"] = pipe_para_lr
        self.pipelines["SGDClassifier"]["pipeline_parameter"] = pipe_para_sgd
        self.pipelines["SVC"]["pipeline_parameter"] = pipe_para_svc
        self.pipelines["MLPClassifier"]["pipeline_parameter"] = pipe_para_mlpC
        self.pipelines["DecisionTreeClassifier"]["pipeline_parameter"] = pipe_para_dtC
        self.pipelines["RandomForestClassifier"]["pipeline_parameter"] = pipe_para_rfC
        self.pipelines["AdaBoostClassifier"]["pipeline_parameter"] = pipe_para_adabC
        self.pipelines["GradientBoostingClassifier"]["pipeline_parameter"] = pipe_para_gbC
        # self.pipelines["XGBClassifier"]["pipeline_parameter"] = pipe_para_xgbC
        self.pipelines["StackingClassifier"]["pipeline_parameter"] = pipe_para_stackingC
        return self


__all__ = ["ClassificationFactory"]
