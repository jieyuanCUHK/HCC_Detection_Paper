__author__ = "Min Li"
# !usr/bin/env python3.7
# coding:utf8

"""
pipeline便于数据挖掘流程的管理
使用sklearn的Pipeline工具自定义一个pipeline装饰器
装饰多个算法，便于多算法比较
"""

__version__ = "1.0.0"


# 算法
from sklearn.linear_model import LinearRegression, Ridge, HuberRegressor, Lasso, ElasticNet, BayesianRidge
from sklearn.kernel_ridge import KernelRidge

from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor

import xgboost as xgb
from xgboost import XGBRegressor

# /lib64/libc.so.6: version `GLIBC_2.14'
# import lightgbm as lgb
# from lightgbm import LGBMRegressor

#from mlxtend.regressor import StackingRegressor
from .abstract_pipeline_factory import AbstractPipeline, AbstractPipelineParameter, AbstractFactory



class RegressionPipeline(AbstractPipeline):
    def multi_algo_pipelines(self):
        @self.pw
        def lR():
            return LinearRegression(n_jobs=8)

        @self.pw
        def rdg():
            return Ridge(random_state=5)

        @self.pw
        def hR():
            return HuberRegressor()

        @self.pw
        def lasso():
            return Lasso(random_state=5)

        @self.pw
        def ela():
            return ElasticNet(random_state=5)

        @self.pw
        def br():
            return BayesianRidge(n_iter=500, compute_score=True)

        @self.pw
        def kr():
            return KernelRidge()

        @self.pw
        def mlpR():
            return MLPRegressor()

        @self.pw
        def dtR():
            return DecisionTreeRegressor()

        @self.pw
        def rfR():
            return RandomForestRegressor(n_jobs=8)

        @self.pw
        def adabR():
            return AdaBoostRegressor(DecisionTreeRegressor(), 
                random_state=5, loss='exponential')

        @self.pw
        def gbR():
            return GradientBoostingRegressor(random_state=5 )

        @self.pw
        def xgbR():
            return XGBRegressor(n_jobs=8, objective='reg:squarederror', metric='rmse', 
                      random_state=5, nthread = 10)

        self.lR = lR
        self.rdg = rdg
        self.hR = hR
        self.lasso = lasso
        self.ela = ela
        self.br = br
        self.kr = kr
        self.mlpR = mlpR
        self.dtR = dtR
        self.rfR = rfR
        self.adabR = adabR
        self.gbR = gbR
        self.xgbR = xgbR
        return self


class RegressionPipelineParameter(AbstractPipelineParameter):
    def multi_algo_pipelines_parameter(self):
        @self.ppw
        def lR():
            return {
            }

        @self.ppw
        def rdg():
            return {
            }

        @self.ppw
        def hR():
            return {
            }

        @self.ppw
        def lasso():
            return {
            }

        @self.ppw
        def ela():
            return {
            }

        @self.ppw
        def br():
            return {
            }

        @self.ppw
        def kr():
            return {
            }

        @self.ppw
        def mplR():
            return {
            }

        @self.ppw
        def adabR():
            return {
            }

        @self.ppw
        def gbR():
            return {
            }

        @self.ppw
        def xgbR():
            return {
            }

        self.lR = lR
        self.rdg = rdg
        self.hR = hR
        self.lasso = lasso
        self.ela = ela
        self.br = br
        self.kr = kr
        self.mlpR = mlpR
        self.dtR = dtR
        self.rfR = rfR
        self.adabR = adabR
        self.gbR = gbR
        self.xgbR = xgbR
        return self


class RegressionFactory(AbstractFactory):
    def create_multi_algo_pipelines(self):
        rp = RegressionPipeline(self.pc).multi_algo_pipelines()
        pipe_lR = rp.lR()
        pipe_rdg = rp.rdg()
        pipe_hR = rp.hR()
        pipe_lasso = rp.lasso()
        pipe_ela = rp.ela()
        pipe_br = rp.br()
        pipe_kr = rp.kr()
        pipe_mlpR = rp.mlpR()
        pipe_dtR = rp.dtR()
        pipe_rfR = rp.rfR()
        pipe_adabR = rp.adabR()
        pipe_gbR = rp.gbR()
        pipe_xgbR = rp.xgbR()
        pipelines = {
            "LinearRegression": {"pipeline": pipe_lR, },
            "Ridge": {"pipeline": pipe_rdg, },
            "HuberRegressor": {"pipeline": pipe_hR, },
            "Lasso": {"pipeline": pipe_lasso, },
            "ElasticNet": {"pipeline": pipe_ela, },
            "br": {"pipeline": pipe_br, },
            "kr": {"pipeline": pipe_kr, },
            "mlpR": {"pipeline": pipe_mlpR, },
            "dtR": {"pipeline": pipe_dtR, },
            "rfR": {"pipeline": pipe_rfR, },
            "adabR": {"pipeline": pipe_adabR, },
            "gbR": {"pipeline": pipe_gbR, },
            "xgbR": {"pipeline": pipe_xgbR},
        }
        self.pipelines = pipelines
        return self

    def add_multi_algo_pipelines_parameter(self):
        cpp = ClassificationPipelineParameter(self.pc).multi_algo_pipelines_parameter()
        pipe_para_lR = cpp.lR()
        pipe_para_rdg = cpp.rdg()
        pipe_para_hR = cpp.hR()
        pipe_para_lasso = cpp.lasso()
        pipe_para_ela = cpp.ela()
        pipe_para_br = cpp.br()
        pipe_para_kr = cpp.kr()
        pipe_para_mlpR = cpp.mlpR()
        pipe_para_dtR = cpp.dtR()
        pipe_para_rfR = cpp.rfR()
        pipe_para_adabR = cpp.adabR()
        pipe_para_gbR = cpp.gbR()
        pipe_para_xgbR = cpp.xgbR()
        self.pipelines["LinearRegression"]["pipeline_parameter"] = pipe_para_lR
        self.pipelines["Ridge"]["pipeline_parameter"] = pipe_para_rdg
        self.pipelines["HuberRegressor"]["pipeline_parameter"] = pipe_para_hR
        self.pipelines["Lasso"]["pipeline_parameter"] = pipe_para_lasso
        self.pipelines["ElasticNet"]["pipeline_parameter"] = pipe_para_ela
        self.pipelines["br"]["pipeline_parameter"] = pipe_para_br
        self.pipelines["kr"]["pipeline_parameter"] = pipe_para_kr
        self.pipelines["mlpR"]["pipeline_parameter"] = pipe_para_mlpR
        self.pipelines["dtR"]["pipeline_parameter"] = pipe_para_dtR
        self.pipelines["rfR"]["pipeline_parameter"] = pipe_para_rfR
        self.pipelines["adabR"]["pipeline_parameter"] = pipe_para_adabR
        self.pipelines["gbR"]["pipeline_parameter"] = pipe_para_gbR
        self.pipelines["xgbR"]["pipeline_parameter"] = pipe_para_xgbR
        return self


__all__ = ["RegressionFactory"]