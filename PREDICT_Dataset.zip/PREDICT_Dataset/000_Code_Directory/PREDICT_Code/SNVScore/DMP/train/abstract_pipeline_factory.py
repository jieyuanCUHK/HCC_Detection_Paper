# !usr/bin/env python3.7
# coding:utf8

"""
pipeline便于数据挖掘流程的管理
使用sklearn的Pipeline工具自定义一个pipeline装饰器
装饰多个算法，便于多算法比较
"""
__version__ = "1.0.0"

#pandas
import pandas as pd
# 数学
import numpy as np
# abc
from abc import abstractmethod
# Pipeline
from sklearn.pipeline import make_pipeline
from sklearn.pipeline import Pipeline
# 数据预处理
# 可以对输入数据处理缺失值
from sklearn.impute import SimpleImputer
# 特征转化
from sklearn import preprocessing as preproc
from sklearn.preprocessing import MinMaxScaler, StandardScaler, RobustScaler, QuantileTransformer
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder
from sklearn.compose import ColumnTransformer
from sklearn.base import BaseEstimator, TransformerMixin
# 降维
from sklearn.decomposition import PCA, SparsePCA
# 网格搜索+交叉验证（降低算法结构风险）
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score, cross_val_predict
from sklearn.metrics import classification_report, roc_curve, auc, recall_score

import seaborn as sns
import matplotlib as mpl
import matplotlib.pyplot as plt


class DenseTransformer(TransformerMixin):
    def transform(self, X, y=None, **fit_params):
        return X.todense()

    def fit_transform(self, X, y=None, **fit_params):
        self.fit(X, y, **fit_params)
        return self.transform(X)

    def fit(self, X, y=None, **fit_params):
        return self
    

# 装饰器配置
class PipelineConfig:
    """
    不同输入数据类型对应不同的pipeline配置
    :param input_flag: int
        input_flag==0表示结构化数据（可能还需要引入别的过程（比如降维））
        input_flag==1表示非结构化数据(往后再扩展)
    :param problem_flag: int
        problem_flag==0分类问题
    :param args: 命名不定长参数
        哪些数据项需要做什么转化等
    """

    def __init__(self, input_flag=0, problem_flag=0, **args):
        self.input_flag = input_flag
        self.problem_flag = problem_flag
        if self.input_flag == 0:
            self.numerical_features = args["numerical_features"]
            self.categorical_features = args["categorical_features"]
            self.other_features = args["other_features"]


# 装饰器（pipeline）
def _pipeline_wrapper(pc):
    """
    不同数据格式输入的数据挖掘pipeline，装饰不同算法
    参数
    -----------
    :pc:PipelineConfig的一个实例，用于配置装饰器
    """

    def structured_data_pipeline(func):
        def wrapper():
            numerical_transformer = Pipeline(
                steps=[
                    ('imputer', SimpleImputer(strategy='median')),
                    ('scaler', MinMaxScaler())
                ]
            )

            categorical_transformer = Pipeline(
                steps=[
                    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
                    ('encoder', OneHotEncoder(handle_unknown='ignore'))
                ]
            )

            preprocessor = ColumnTransformer(
                transformers=[
                    ('num', numerical_transformer, pc.numerical_features),
                    ('cat', categorical_transformer, pc.categorical_features),
                    ('other', numerical_transformer, pc.other_features)
                ]
            )
            dimension_reduction = PCA(n_components=0.99)
            pipeline = Pipeline(
                steps=[  ('preprocessor', preprocessor),
                       #("dimension_reduction",dimension_reduction),
                       (func.__name__, func())
                ]
            )
            return pipeline

        return wrapper

    if pc.input_flag == 0:
        return structured_data_pipeline
    return None


# 装饰器（pipeline_parameter）
def _pipeline_parameter_wrapper(pc):
    """
    不同数据格式输入的数据挖掘pipeline，装饰不同算法
    参数
    -----------
    :pc:PipelineParameterConfig的一个实例，用于配置装饰器
    """

    def structured_data_pipeline_parameter(func):
        def wrapper():
            list_scalers = [
                StandardScaler(),
                MinMaxScaler(),
                RobustScaler(),
                QuantileTransformer(output_distribution='normal')
            ]
            list_encoder = [
                OneHotEncoder(handle_unknown='ignore'),
            ]
            parameters = {
                'preprocessor__num__scaler': list_scalers,
                'preprocessor__cat__encoder': list_encoder,
#                 'dimension_reduction__n_components': [0.99, 0.90, 1]
            }
            parameters.update(func())
            return parameters

        return wrapper

    if pc.input_flag == 0:
        return structured_data_pipeline_parameter
    return None


# Pipeline抽象类，不同的问题对应不同的pipeline
class AbstractPipeline:
    def __init__(self, pc):
        self.pw = _pipeline_wrapper(pc)

    @abstractmethod
    def multi_algo_pipelines(self):
        pass


# PipelineParameter抽象类，不同的问题对应不同的PipelineParameter
class AbstractPipelineParameter:
    def __init__(self, pc):
        self.ppw = _pipeline_parameter_wrapper(pc)

    @abstractmethod
    def multi_algo_pipelines_parameter(self):
        pass


# 抽象工厂，不同的问题对应不同的车间（装配线，这里的线与我们的pipeline不一样）
class AbstractFactory:
    def __init__(self, pc):
        self.pc = pc

    @abstractmethod
    def create_multi_algo_pipelines(self):  # 装配算法
        pass

    @abstractmethod
    def add_multi_algo_pipelines_parameter(self):  # 装配算法的参数
        pass

    def get_pipelines(self):
        return self.pipelines


# 不同的问题对应不同的scoring，这个函数需要根据pipeline_config问题做适配性优化
# 算法名可能也需要修改
def cross_val_upscore_report(X, y, pipelines, scoring='f1'):
    """
    打印多个模型的交叉验证的评分结果
    参数
    ----------------
    X：特征
    y：预测目标
    pipelines：多个模型的pipeline
    scoring：评分，这里选用取值越大越好的指标如f1，recall，accuracy
    """
    print("model", "\t", scoring, "\t", "std", "\t", "\t", "max {}".format(scoring))
    print("-+" * 30)
    for pipe in pipelines:
        scores = cross_val_score(pipe, X, y, scoring=scoring, cv=5)
        if scoring=='neg_mean_squared_error':
            scores = np.sqrt(-scores)
        print(pipe.steps[-1][0], "\t",
              '{:08.6f}'.format(np.mean(scores)), "\t",
              '{:08.6f}'.format(np.std(scores)), "\t",
              '{:08.6f}'.format(np.max(scores)))
        
        
#计算特异性为95%时的敏感性
def at_t_Specificity(fpr, t):
    for n,f in enumerate(fpr):
        if f-t >=0:
            Specificity_t = n-1
            break
    return Specificity_t

def at_t_thresholds(thresholds, t):
    for n,th in enumerate(thresholds):
        if th-t <=0:
            thresholds_t = n-1
            break
    return thresholds_t

#SVM简单5折交叉验证结果绘制ROC曲线        
def drawROC_t_Specificity(pre, y, t):
    #print(pipeline.steps[-1][0])
    #probs = cross_val_predict(pipeline, X, y, cv=5, method='predict_proba')
    #probs_df = pd.DataFrame(probs)
    #probs_df.index = X.index
    #X_pre = pd.concat([X, probs_df], axis=1)
    #错误样本统计
    fpr, tpr, thresholds = roc_curve(y, pre)
    roc_auc = auc(fpr, tpr)
    n = at_t_Specificity(fpr, t)
    print (
    u"样本在特异性为{}时，敏感性为:{}".format(1-fpr[n],tpr[n]),u"，要判定为阳性需要p(1)>=", thresholds[n],
    )
    #画ROC图
    sns.set(color_codes=True)
    plt.scatter(fpr,tpr,color='green',marker='o',edgecolor='black',alpha=0.5)
    plt.plot( [t, t],[0, 1], '--', color=(0.6, 0.6, 0.6))
    plt.plot(fpr, tpr, 'k--', label='ROC curve (area = %0.2f)' % roc_auc, lw=2)
    plt.legend(loc="lower right")
    plt.savefig("ROC.png",dpi=300)
    #return X_pre

def drawROC_t_thresholds(pre, y, t):
    #print(pipeline.steps[-1][0])
    #probs = cross_val_predict(pipeline, X, y, cv=5, method='predict_proba')
    #probs_df = pd.DataFrame(probs)
    #probs_df.index = X.index
    #X_pre = pd.concat([X, probs_df], axis=1)
    #错误样本统计
    fpr, tpr, thresholds = roc_curve(y, pre)
    roc_auc = auc(fpr, tpr)
    n = at_t_thresholds(thresholds, t)
    print (
    u"样本在特异性为{}时，敏感性为:{}".format(1-fpr[n],tpr[n]),u"，要判定为阳性需要p(1)>=", thresholds[n],
    )
    #画ROC图
    sns.set(color_codes=True)
    plt.scatter(fpr,tpr,color='green',marker='o',edgecolor='black',alpha=0.5)
    plt.plot( [0.05, 0.05],[0, 1], '--', color=(0.6, 0.6, 0.6))
    plt.plot(fpr, tpr, 'k--', label='ROC curve (area = %0.2f)' % roc_auc, lw=2)
    plt.legend(loc="lower right")
    plt.savefig("ROC.png",dpi=300)
    #return X_pre


# 不同的问题对应不同的scoring，这个函数需要根据pipeline_config问题做适配性优化
# 算法名可能也需要修改
def grid_search_cv(X, y, pipe_algo, pipe_para_algo, scoring='f1', n_jobs=5):
    gscv_algo = GridSearchCV(pipe_algo, pipe_para_algo, n_jobs=n_jobs, # n_jobs=-1, n_job的默认值是2
                             scoring=scoring, verbose=0, cv=5)
    gscv_algo.fit(X, y)
    gscv_algo.estimator.fit(X, y)
    return gscv_algo.estimator, gscv_algo.best_score_


__all__ = ["PipelineConfig",
           "AbstractPipeline",
           "AbstractPipelineParameter",
           "AbstractFactory",
           "cross_val_upscore_report",
           "grid_search_cv"]
