# !/usr/bin/env python3.7
# coding:utf8

import os
import subprocess
import argparse
from pathlib import Path
appdir = Path(__file__).resolve().parent


def opt():
    args = argparse.ArgumentParser()
    args.add_argument('-b', '--bam', dest='single sample offtarget bam', required=True,
                      help="one sample offtarget bam, [str]")
    args.add_argument('-f', '--reference', dest='reference genome', required=True,
                      help="reference genome [hs37d5.fa], [str]")
    args.add_argument('-o', '--outdir', dest='output directory', required=False,
                      help="the output directory, [str]")
    return args.parse_args()


def checkPath(*paths):
    """
    check path exists or not
    """
    for path in paths:
        if not os.path.exists(path):
            os.makedirs(path, mode=0o777)
        else:
            print ("path %s exists" % path)


def extractName(bamPath):
    """
    identify sample id
    """
    bamName = os.path.split(bamPath)[1]
    sample = "_".join(bamName.split("_")[0:2])
    return sample


def offTarget_ifs(offbam, refgenome, nucleo_footprint, flk=2500):
    """
    calculate ifs and save it to nucleo_footprint dirs, those are fraggc,ifs,footprint,tss_2500,diff_2500
    """
    sampleid = extractName(offbam)

    # file names
    fraggc = "{}/{}".format(nucleo_footprint,"fraggc")
    fggc_gz_file = "{}/{}_fraggc.gz".format(fraggc, sampleid)
    ifs = "{}/{}".format(nucleo_footprint,"ifs")
    ifs_gz_tmp = "{}/{}_ifs".format(ifs, sampleid)
    ifs_gz_file = "{}/{}_ifs.gz".format(ifs, sampleid)
    footprint = "{}/{}".format(nucleo_footprint,"footprint")
    footprint_file = "{}/{}_tss_footprint.tsv".format(footprint, sampleid)
    tss = "{}/tss_{}".format(nucleo_footprint,flk)
    tss_ifs_file = "{}/{}_tss_ifs.tsv".format(tss, sampleid)
    diff = "{}/diff_{}".format(nucleo_footprint,flk)
    diff_ifs_file = "{}/{}.diff_ifs.tsv".format(diff, sampleid)
    checkPath(fraggc, ifs, footprint, tss, diff, ifs_gz_tmp)
    
    reference = refgenome
    # reference = "/refgenomes/hs37d5/hs37d5.fa" 

    # commands
    bam2frag_cmd = "{0}/bin/bam_to_fraggc_v1.4 --bam {1} --reference {2} --maxFragSize 1000 --minFragSize 30 --removeDuplicate --mapQual 30 | sort -k 1,1V -k 2,2g -k 3,3g | bgzip -c > {3} && tabix -f -s 1 -b 2 -e 3 {3}".format(appdir, offbam, reference, fggc_gz_file)
    get_ifs1_cmd = "cat {0}/config/reference-pq.bed | while read chrom start end arm; do cd {1} && tabix {2} ${{chrom}}:${{start}}-${{end}} > {1}/{3}.${{arm}}.tmp && python3 {0}/bin/fggc_to_ifs.py {1}/{3}.${{arm}}.tmp | sort -k 2,2g -S 3G | bgzip -c > {1}/{3}.${{arm}}.ifs.gz && tabix -f -s 1 -b 2 -e 2 {1}/{3}.${{arm}}.ifs.gz && rm {1}/{3}.${{arm}}.tmp; done".format(appdir, ifs_gz_tmp, fggc_gz_file, sampleid)
    get_ifs2_cmd = "cut -f 4 {0}/config/reference-pq.bed | xargs -i sh -c \"zcat {1}/*.{{}}.ifs.gz\" | grep -v \"^#\" |sort -k 1,1V -k 2,2g -k 3,3g | bgzip -c > {2} && tabix -f -s 1 -b 2 -e 2 {2} && rm -rf {1}".format(appdir, ifs_gz_tmp, ifs_gz_file)
    get_ifs_cmd = "{} && {}".format(get_ifs1_cmd, get_ifs2_cmd)
    cal_tssifs1_cmd = "python3 {0}/bin/tss_ifs.py footprint {0}/config/refTSS_remove_highDP.bed {1} {2} {3}".format(appdir, ifs_gz_file, footprint_file, "5000")
    cal_tssifs2_cmd = "python3 {0}/bin/tss_ifs.py ifs {0}/config/refTSS_remove_lowMappability.bed {0}/config/reference-pq.bed {1} {2} {3}".format(appdir, ifs_gz_file, tss_ifs_file, "2500")
    cal_tssifs_cmd = "{} && {}".format(cal_tssifs1_cmd, cal_tssifs2_cmd)
    diff_tssifs_cmd = "python3 {0}/bin/tss_ifs.py diff {1} {0}/config/nf_diff_list.tsv {2}".format(appdir, tss_ifs_file, diff_ifs_file)

    # step1: get read len and gc
    if not os.path.exists(fggc_gz_file):
        print("bam path: {}".format(offbam))
        bam2frag = subprocess.call(bam2frag_cmd, shell=True)
        if bam2frag != 0:
            print("ERROR {}".format(bam2frag_cmd))
            print("FAIL")
            exit(1)
        else:
            print("bam to fragment SUCCEEDED")

    # step2: get ifs from read len and gc
    if not os.path.exists(ifs_gz_file):
        get_ifs = subprocess.call(get_ifs_cmd, shell=True)
        if get_ifs != 0:
            print("ERROR {}".format(get_ifs_cmd))
            print("FAIL")
            exit(1)
        else:
            print("get ifs SUCCEEDED")
    
    # step3: calculate tss ifs
    if not os.path.exists(tss_ifs_file):
        cal_tssifs = subprocess.call(cal_tssifs_cmd, shell=True)
        if cal_tssifs != 0:
            print("ERROR {}".format(cal_tssifs_cmd))
            print("FAIL")
            exit(1)
        else:
            print("calculate tss ifs SUCCEEDED")

    # step4: get diff tss ifs
    if not os.path.exists(diff_ifs_file):
        diff_tssifs = subprocess.call(diff_tssifs_cmd, shell=True)
        if diff_tssifs != 0:
            print("ERROR {}".format(diff_tssifs_cmd))
            print("FAIL")
            exit(1)
        else:
            print("get diff tss ifs SUCCEEDED")


def main():
    args = opt()
    bam = args.bam
    refgenome = args.refgenome
    ifs_path = args.output
    flk = 2500
    offTarget_ifs(bam, refgenome, ifs_path, flk)


if __name__ == "__main__":
    main()
